import streamlit as st
import pandas as pd
import json
import os
from datetime import datetime
from langchain_ollama import ChatOllama

# --- LLM INITIALIZATION ---
model = ChatOllama(model="llama3.2:latest", temperature=0.1)

# --- PERSISTENT STORAGE HELPERS ---
STORE_FILE = r"C:\Users\Ranjith\Desktop\Risk_Engineering\data\agent_store.csv"
STORE_COLUMNS = [
    "client_id", "data_ingession", "data_gathering", "data_validation", 
    "risk_assessment", "risk_assessment_report", "risk_mitigation", 
    "risk_mitiation_result", "physical_inspection", "physical_inspection_report", 
    "remote_inspection", "remote_inspection_report", "risk_profile", "risk_profile_report"
]

def init_store():
    if not os.path.exists(STORE_FILE):
        df = pd.DataFrame(columns=STORE_COLUMNS)
        df.to_csv(STORE_FILE, index=False)

def get_client_status(cid):
    # Ensure NaNs are handled as empty strings for Streamlit compatibility
    df = pd.read_csv(STORE_FILE).fillna("") 
    client_row = df[df['client_id'] == cid]
    
    if client_row.empty:
        new_row = {col: "Pending" if "report" not in col and "result" not in col else "" for col in STORE_COLUMNS}
        new_row['client_id'] = cid
        df = pd.concat([df, pd.DataFrame([new_row])], ignore_index=True)
        df.to_csv(STORE_FILE, index=False)
        return new_row
        
    return client_row.iloc[0].to_dict()

def update_client_store(cid, column, value):
    df = pd.read_csv(STORE_FILE)
    # Ensure the row exists
    if cid not in df['client_id'].values:
        new_row = pd.DataFrame([{col: "" for col in STORE_COLUMNS}])
        new_row['client_id'] = cid
        df = pd.concat([df, new_row], ignore_index=True)
    
    # Update specifically at that row/column intersection
    df.loc[df['client_id'] == cid, column] = value
    df.to_csv(STORE_FILE, index=False)

# --- [RiskAssessmentEngine Class remains the same as your previous code] ---
# ... (Include your RiskAssessmentEngine class here) ...

# --- PAGE SETUP ---
st.set_page_config(page_title="Agentic Risk Orchestrator", layout="wide")
init_store()

EXCEL_PATH = r'C:\Users\Ranjith\Desktop\Risk_Engineering\data\data.xlsx'
try:
    all_props = pd.read_excel(EXCEL_PATH, sheet_name='property_details')
except:
    st.error("Missing data.xlsx")
    st.stop()

# --- SIDEBAR & SELECTION ---
st.sidebar.title("Orchestrator Control")
selected_cid = st.sidebar.selectbox("Select Client ID", all_props['client_id'].unique())
client_data = all_props[all_props['client_id'] == selected_cid].iloc[0]
status = get_client_status(selected_cid)

# Sidebar Status
st.sidebar.subheader("Live Workflow Progress")
agent_list = ["data_ingession", "data_gathering", "risk_assessment", "physical_inspection", "remote_inspection", "risk_profile"]
for agent in agent_list:
    val = status.get(agent, "Pending")
    color = "green" if val == "Completed" else "orange"
    st.sidebar.markdown(f"**{agent.replace('_', ' ').title()}**: :{color}[{val}]")

# --- MAIN UI ---
st.title(f"Risk Engineering: {client_data['property_name']}")

# --- WORKFLOW SELECTOR ---
if status["data_ingession"] == "Pending":
    st.warning("### 🤖 Orchestrator Decision Required")
    st.write("How would you like to proceed with this risk?")
    col_a, col_b = st.columns(2)
    with col_a:
        if st.button("🚀 Fast-Track (Risk Assessment Only)", use_container_width=True):
            update_client_store(selected_cid, "physical_inspection", "Skipped")
            update_client_store(selected_cid, "remote_inspection", "Skipped")
            update_client_store(selected_cid, "data_ingession", "Ready")
            st.rerun()
    with col_b:
        if st.button("🔍 Comprehensive (With Field Inspections)", use_container_width=True):
            update_client_store(selected_cid, "data_ingession", "Ready")
            st.rerun()
    st.stop()

# --- TABS ---
tab_auto, tab_inspect, tab_prof = st.tabs(["⚡ Automated Pipeline", "🛡️ Field Intelligence", "📄 Final Risk Profile"])

# TAB 1: AUTOMATED AGENTS
with tab_auto:
    st.header("Core Risk Agents")
    if st.button("▶️ Execute Automated Agents"):
        with st.spinner("Executing Ingestion, Gathering, and Analytics..."):
            # Update sequence
            update_client_store(selected_cid, "data_ingession", "Completed")
            update_client_store(selected_cid, "data_gathering", "Completed")
            update_client_store(selected_cid, "data_validation", "Completed")
            
            # Use your engine to get the JSON
            # engine = RiskAssessmentEngine(EXCEL_PATH)
            # report_json = engine.assess_claim(selected_cid)
            report_json = {"derived": {"risk_grade": "B", "score": 0.72}} # Mock for demo
            
            update_client_store(selected_cid, "risk_assessment", "Completed")
            update_client_store(selected_cid, "risk_assessment_report", json.dumps(report_json))
            st.success("Automated processing complete.")
            st.rerun()

    if status["risk_assessment_report"]:
        st.json(json.loads(status["risk_assessment_report"]))

# TAB 2: FIELD INTELLIGENCE (PHYSICAL & REMOTE)
with tab_inspect:
    if status["physical_inspection"] == "Skipped":
        st.info("Field inspections were skipped during fast-track setup.")
    else:
        st.header("Field Intelligence Agents")
        p_col, r_col = st.columns(2)
        
        with p_col:
            st.subheader("👷 Physical Inspection")
            if st.button("📧 Dispatch Physical Surveyor"):
                update_client_store(selected_cid, "physical_inspection", "Mail Sent")
                st.info("Email dispatched to nearby surveyors.")
            
            uploaded_p = st.file_uploader("Upload Physical Survey", key="up_p")
            if uploaded_p:
                content = uploaded_p.read().decode()
                update_client_store(selected_cid, "physical_inspection", "Completed")
                update_client_store(selected_cid, "physical_inspection_report", content)
                st.success("Physical report stored.")
                st.rerun()

        with r_col:
            st.subheader("📱 Remote Inspection")
            if st.button("📧 Send Customer Questionnaire"):
                update_client_store(selected_cid, "remote_inspection", "Mail Sent")
                st.info("Email dispatched to property manager.")
            
            uploaded_r = st.file_uploader("Upload Customer Responses", key="up_r")
            if uploaded_r:
                content = uploaded_r.read().decode()
                update_client_store(selected_cid, "remote_inspection", "Completed")
                update_client_store(selected_cid, "remote_inspection_report", content)
                st.success("Remote report stored.")
                st.rerun()

# TAB 3: AUTO-GENERATED PROFILE
with tab_prof:
    st.header("Final Risk Profile")
    
    # AUTO-TRIGGER LOGIC: 
    # If Core + (Inspections or Skipped) are done but Profile is not
    can_profile = status["risk_assessment"] == "Completed"
    if status["physical_inspection"] != "Skipped":
        can_profile = can_profile and (status["physical_inspection"] == "Completed")
    
    if can_profile and status["risk_profile"] != "Completed":
        with st.spinner("🤖 All data gathered. Profiling Agent starting automatically..."):
            # Combine all for LLM
            combined = {
                "assessment": json.loads(status["risk_assessment_report"]),
                "physical": status["physical_inspection_report"],
                "remote": status["remote_inspection_report"]
            }
            # [Your prompt logic from earlier...]
            final_md = "## Generated Risk Profile\nThis is a mock generated report based on agent inputs."
            update_client_store(selected_cid, "risk_profile", "Completed")
            update_client_store(selected_cid, "risk_profile_report", final_md)
            st.rerun()

    if status["risk_profile_report"]:
        st.markdown(status["risk_profile_report"])
        st.download_button("📥 Download Report", status["risk_profile_report"], file_name="RiskProfile.md")
    else:
        st.info("Awaiting completion of previous agents to generate profile.")