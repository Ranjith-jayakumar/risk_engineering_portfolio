from ml_algo.fire_risk.model.fire_risk_model import FIRE_RISK_Model
from ml_algo.natcat.model.nat_cat_model import NATCAT_Model
from ml_algo.operational_risk.model.operational_risk_model import OPERATIONAL_RISK_Model
fire_model = FIRE_RISK_Model(degree=2)

user_input = {
        "sprinkler_score": 0.8,
        "fire_brigade_score": 0.7,
        "detection_score": 1,
        "housekeeping_score": 0.6
    }
prediction = fire_model.inference(user_input)
print("Predicted Fire Risk Score:", prediction)


natcat_model = NATCAT_Model(degree=2)

user_input = {
        "flood_score": 0.6,
        "earthquake_score": 0.9,
        "wind_score": 0.45
    }
prediction = natcat_model.inference(user_input)
print("Predicted NatCat Score:", prediction)


op_model = OPERATIONAL_RISK_Model(degree=2)

user_input = {
        "single_site": 1,
        "critical_process": 1,
        "normalized_bi": 0.75,
        "loss_flag": 0
    }
prediction = op_model.inference(user_input)
print("Predicted Operational Risk Score:", prediction)

